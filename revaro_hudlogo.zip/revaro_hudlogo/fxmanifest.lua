fx_version 'cerulean'
game 'gta5'

author 'Revaro Team'
description 'HUD Logo oben rechts'

files {
    'html/ui.html',
    'html/style.css',
    'html/logo_topright.png'
}

ui_page 'html/ui.html'

client_script 'client.lua'
