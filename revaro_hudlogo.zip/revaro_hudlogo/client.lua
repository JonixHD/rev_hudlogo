-- HUD-Logo aktivieren
CreateThread(function()
    Wait(1000)
    SendNUIMessage({ type = "showLogo" })
end)
